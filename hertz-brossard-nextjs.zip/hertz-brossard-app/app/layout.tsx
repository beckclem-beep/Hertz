import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata={title:'Hertz Brossard — Tesla Scanner',description:'Recherche rapide des disponibilités et prix Hertz à Brossard.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
